class DataSaya {
  static String nama = "marni";
  static String gambar = "assets/gambar_saya.jpg";
}
